import { GoogleGenAI } from '@google/genai';
import {
  ProviderConfig,
  ProviderType,
  ModelCombo,
  SmartIntentRoute,
  GatewayRequestLog,
  GatewayStats,
  FailoverEvent,
  CascadeStep,
} from '../src/types/gateway.js';
import {
  DEFAULT_PROVIDERS,
  DEFAULT_COMBOS,
  DEFAULT_SMART_ROUTES,
} from './defaultConfig.js';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface CompletionRequestOptions {
  model: string;
  messages: ChatMessage[];
  stream?: boolean;
  temperature?: number;
  max_tokens?: number;
  simulateFailureOnPrimary?: boolean;
}

export class GatewayEngine {
  private providers: Map<ProviderType, ProviderConfig> = new Map();
  private combos: Map<string, ModelCombo> = new Map();
  private smartRoutes: SmartIntentRoute[] = [];
  private logs: GatewayRequestLog[] = [];
  private stats: GatewayStats = {
    totalRequests: 0,
    successRate: 100,
    failoversRecovered: 0,
    avgLatencyMs: 290,
    totalTokens: 0,
    uptimeHours: 99.99,
    activeProviders: 0,
    activeCombos: 0,
  };
  private startTime = Date.now();

  constructor() {
    this.init();
  }

  private init() {
    // Populate providers
    for (const p of DEFAULT_PROVIDERS) {
      this.providers.set(p.id, { ...p });
    }
    // Check Gemini API key from environment
    const gemini = this.providers.get('gemini');
    if (gemini) {
      gemini.hasEnvKey = !!process.env.GEMINI_API_KEY;
      if (process.env.GEMINI_API_KEY && !gemini.apiKey) {
        gemini.apiKey = process.env.GEMINI_API_KEY;
      }
    }

    // Populate combos
    for (const c of DEFAULT_COMBOS) {
      this.combos.set(c.slug, { ...c });
    }

    this.smartRoutes = [...DEFAULT_SMART_ROUTES];
    this.updateStatsCounters();
  }

  public getProviders(): ProviderConfig[] {
    return Array.from(this.providers.values()).map(p => ({
      ...p,
      // Mask API keys for security in public inspection
      apiKey: p.apiKey ? (p.apiKey.length > 8 ? `${p.apiKey.slice(0, 4)}...${p.apiKey.slice(-4)}` : '••••••••') : '',
    }));
  }

  public getRawProvider(id: ProviderType): ProviderConfig | undefined {
    return this.providers.get(id);
  }

  public updateProvider(id: ProviderType, updates: Partial<ProviderConfig>): ProviderConfig | null {
    const provider = this.providers.get(id);
    if (!provider) return null;

    if (updates.apiKey !== undefined && updates.apiKey.trim() !== '') {
      provider.apiKey = updates.apiKey.trim();
    }
    if (updates.enabled !== undefined) provider.enabled = updates.enabled;
    if (updates.simulateFailover !== undefined) provider.simulateFailover = updates.simulateFailover;
    if (updates.simulateErrorType !== undefined) provider.simulateErrorType = updates.simulateErrorType;
    if (updates.baseUrl !== undefined) provider.baseUrl = updates.baseUrl;

    this.updateStatsCounters();
    return provider;
  }

  public getCombos(): ModelCombo[] {
    return Array.from(this.combos.values());
  }

  public saveCombo(combo: ModelCombo): ModelCombo {
    this.combos.set(combo.slug, combo);
    this.updateStatsCounters();
    return combo;
  }

  public deleteCombo(slug: string): boolean {
    if (this.combos.has(slug)) {
      this.combos.delete(slug);
      this.updateStatsCounters();
      return true;
    }
    return false;
  }

  public getSmartRoutes(): SmartIntentRoute[] {
    return this.smartRoutes;
  }

  public updateSmartRoutes(routes: SmartIntentRoute[]): void {
    this.smartRoutes = routes;
  }

  public getLogs(): GatewayRequestLog[] {
    return this.logs.slice(0, 50);
  }

  public getStats(): GatewayStats {
    const uptimeHrs = Math.max(0.1, Number(((Date.now() - this.startTime) / (1000 * 3600)).toFixed(1)));
    return {
      ...this.stats,
      uptimeHours: uptimeHrs,
    };
  }

  private updateStatsCounters() {
    let activeP = 0;
    for (const p of this.providers.values()) {
      if (p.enabled && (p.apiKey || (p.id === 'gemini' && process.env.GEMINI_API_KEY))) {
        activeP++;
      }
    }
    this.stats.activeProviders = activeP;
    this.stats.activeCombos = this.combos.size;
  }

  /**
   * Smart Intent Classifier to pick the best cascade for prompt content
   */
  public classifyIntent(promptText: string): { category: string; preferredComboSlug: string; reason: string } {
    const lower = promptText.toLowerCase();

    for (const route of this.smartRoutes) {
      if (route.category === 'general') continue;
      const matched = route.keywords.filter(k => lower.includes(k.toLowerCase()));
      if (matched.length > 0) {
        const combo = Array.from(this.combos.values()).find(c => c.id === route.preferredComboId);
        return {
          category: route.category,
          preferredComboSlug: combo ? combo.slug : 'onez-auto',
          reason: `Matched ${matched.length} keyword(s) for ${route.label} (${matched.slice(0, 3).join(', ')})`,
        };
      }
    }

    return {
      category: 'general',
      preferredComboSlug: 'onez-bulletproof',
      reason: 'Standard conversational query without specialized keywords',
    };
  }

  /**
   * Resolve an incoming model request into an ordered cascade of provider steps
   */
  public resolveCascade(requestedModel: string, promptText: string): {
    effectiveCombo: string;
    steps: CascadeStep[];
    strategy: string;
    intentReason?: string;
  } {
    // 1. Direct combo match
    const combo = this.combos.get(requestedModel);
    if (combo) {
      if (combo.routingStrategy === 'smart-intent') {
        const intent = this.classifyIntent(promptText);
        const subCombo = this.combos.get(intent.preferredComboSlug);
        if (subCombo && subCombo.slug !== combo.slug) {
          return {
            effectiveCombo: `${combo.slug} -> [${intent.category}] ${subCombo.slug}`,
            steps: subCombo.cascade,
            strategy: 'smart-intent',
            intentReason: intent.reason,
          };
        }
      }
      return {
        effectiveCombo: combo.slug,
        steps: combo.cascade,
        strategy: combo.routingStrategy,
      };
    }

    // 2. Direct provider model match (e.g. "llama-3.3-70b-versatile" or "gemini-3.8-flash")
    for (const provider of this.providers.values()) {
      const foundModel = provider.models.find(m => m.id === requestedModel);
      if (foundModel) {
        // Construct single-model cascade with fallback to Gemini Flagship
        const steps: CascadeStep[] = [
          { providerId: provider.id, modelId: foundModel.id, label: `Direct: ${foundModel.name}` },
          { providerId: 'gemini', modelId: 'gemini-3.8-flash', label: 'Safety Net: Gemini 3.8 Flash' },
        ];
        return {
          effectiveCombo: `direct:${requestedModel}`,
          steps,
          strategy: 'direct-with-fallback',
        };
      }
    }

    // 3. Fallback to default auto-router
    const autoCombo = this.combos.get('onez-auto') || DEFAULT_COMBOS[0];
    const intent = this.classifyIntent(promptText);
    return {
      effectiveCombo: autoCombo.slug,
      steps: autoCombo.cascade,
      strategy: 'smart-intent-fallback',
      intentReason: intent.reason,
    };
  }

  /**
   * Central chat completion execution with instant, automatic failover
   */
  public async executeChatCompletion(options: CompletionRequestOptions): Promise<{
    id: string;
    content: string;
    resolvedProvider: ProviderType;
    resolvedModel: string;
    failovers: FailoverEvent[];
    latencyMs: number;
    usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
  }> {
    const startTime = Date.now();
    const promptText = options.messages.map(m => m.content).join('\n');
    const { effectiveCombo, steps } = this.resolveCascade(options.model, promptText);

    const failovers: FailoverEvent[] = [];
    let successfulResult: {
      content: string;
      providerId: ProviderType;
      modelId: string;
      promptTokens: number;
      completionTokens: number;
    } | null = null;

    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      const provider = this.providers.get(step.providerId);
      const stepStartTime = Date.now();

      // Check if simulated failure is triggered
      const isSimulatedFail = (options.simulateFailureOnPrimary && i === 0) || (provider?.simulateFailover ?? false);

      if (isSimulatedFail) {
        const errorType = provider?.simulateErrorType || '402-quota-exhausted';
        let reason = '402 Insufficient account credits: Provider balance depleted';
        let statusCode = 402;

        if (errorType === '429-rate-limit') {
          reason = '429 Rate limit exceeded: TPM / RPM capacity reached';
          statusCode = 429;
        } else if (errorType === '503-server-error') {
          reason = '503 Service Unavailable: Provider backend overload';
          statusCode = 503;
        } else if (errorType === 'timeout') {
          reason = 'Gateway Timeout: Response took > 10,000ms';
          statusCode = 504;
        }

        failovers.push({
          stepIndex: i,
          providerId: step.providerId,
          modelId: step.modelId,
          errorReason: `[Simulated Failover] ${reason}`,
          statusCode,
          timestamp: Date.now(),
          latencyMs: Date.now() - stepStartTime,
        });
        continue;
      }

      // Check if provider is enabled
      if (!provider || !provider.enabled) {
        failovers.push({
          stepIndex: i,
          providerId: step.providerId,
          modelId: step.modelId,
          errorReason: `Provider '${step.providerId}' is disabled in configuration`,
          timestamp: Date.now(),
          latencyMs: 1,
        });
        continue;
      }

      // Check if provider has API key
      const effectiveKey = provider.apiKey || (step.providerId === 'gemini' ? process.env.GEMINI_API_KEY : '');
      if (!effectiveKey) {
        failovers.push({
          stepIndex: i,
          providerId: step.providerId,
          modelId: step.modelId,
          errorReason: `Provider '${step.providerId}' has no API key configured. Auto-skipping to next node.`,
          timestamp: Date.now(),
          latencyMs: 1,
        });
        continue;
      }

      // Attempt provider call
      try {
        const result = await this.callProviderModel({
          providerId: step.providerId,
          modelId: step.modelId,
          apiKey: effectiveKey,
          baseUrl: provider.baseUrl,
          messages: options.messages,
          temperature: options.temperature,
          max_tokens: options.max_tokens,
        });

        successfulResult = {
          content: result.content,
          providerId: step.providerId,
          modelId: step.modelId,
          promptTokens: result.promptTokens,
          completionTokens: result.completionTokens,
        };
        break;
      } catch (err: unknown) {
        const errMsg = err instanceof Error ? err.message : String(err);
        const statusCode = (err as { status?: number; statusCode?: number })?.status || 500;

        failovers.push({
          stepIndex: i,
          providerId: step.providerId,
          modelId: step.modelId,
          errorReason: `Call failed: ${errMsg.slice(0, 160)}`,
          statusCode,
          timestamp: Date.now(),
          latencyMs: Date.now() - stepStartTime,
        });
        // Continue loop to fallback!
      }
    }

    // If still no successful result, fall back directly to server Gemini as absolute guarantee
    if (!successfulResult) {
      const geminiStartTime = Date.now();
      try {
        const geminiKey = process.env.GEMINI_API_KEY;
        if (!geminiKey) {
          throw new Error('No GEMINI_API_KEY found in server environment');
        }
        const result = await this.callGeminiDirect(geminiKey, 'gemini-3.8-flash', options.messages);
        successfulResult = {
          content: result.content,
          providerId: 'gemini',
          modelId: 'gemini-3.8-flash',
          promptTokens: result.promptTokens,
          completionTokens: result.completionTokens,
        };
      } catch (geminiErr: unknown) {
        const errMsg = geminiErr instanceof Error ? geminiErr.message : String(geminiErr);
        throw new Error(`All providers in cascade failed and emergency fallback failed: ${errMsg}`);
      }
    }

    const totalLatency = Date.now() - startTime;
    const reqId = `oz-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const usage = {
      prompt_tokens: successfulResult.promptTokens || Math.ceil(promptText.length / 4),
      completion_tokens: successfulResult.completionTokens || Math.ceil(successfulResult.content.length / 4),
      total_tokens: (successfulResult.promptTokens || 0) + (successfulResult.completionTokens || 0),
    };

    // Log request
    const logEntry: GatewayRequestLog = {
      id: reqId,
      timestamp: Date.now(),
      requestedModel: options.model,
      actualProvider: successfulResult.providerId,
      actualModel: successfulResult.modelId,
      status: failovers.length > 0 ? 'recovered_via_failover' : 'success',
      promptPreview: promptText.slice(0, 100),
      responsePreview: successfulResult.content.slice(0, 140),
      latencyMs: totalLatency,
      tokens: {
        prompt: usage.prompt_tokens,
        completion: usage.completion_tokens,
        total: usage.total_tokens,
      },
      failovers,
      streaming: !!options.stream,
    };
    this.logs.unshift(logEntry);
    if (this.logs.length > 100) this.logs.pop();

    // Update global metrics
    this.stats.totalRequests++;
    if (failovers.length > 0) {
      this.stats.failoversRecovered++;
    }
    this.stats.totalTokens += usage.total_tokens;
    this.stats.avgLatencyMs = Math.round((this.stats.avgLatencyMs * 0.9) + (totalLatency * 0.1));

    return {
      id: reqId,
      content: successfulResult.content,
      resolvedProvider: successfulResult.providerId,
      resolvedModel: successfulResult.modelId,
      failovers,
      latencyMs: totalLatency,
      usage,
    };
  }

  /**
   * Internal dispatcher for various providers
   */
  private async callProviderModel(params: {
    providerId: ProviderType;
    modelId: string;
    apiKey: string;
    baseUrl?: string;
    messages: ChatMessage[];
    temperature?: number;
    max_tokens?: number;
  }): Promise<{ content: string; promptTokens: number; completionTokens: number }> {
    const { providerId, modelId, apiKey, baseUrl, messages, temperature, max_tokens } = params;

    if (providerId === 'gemini') {
      return this.callGeminiDirect(apiKey, modelId, messages, temperature);
    }

    if (providerId === 'groq') {
      return this.callOpenAICompatible({
        endpoint: 'https://api.groq.com/openai/v1/chat/completions',
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    if (providerId === 'openai') {
      return this.callOpenAICompatible({
        endpoint: 'https://api.openai.com/v1/chat/completions',
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    if (providerId === 'anthropic') {
      return this.callAnthropic({
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    if (providerId === 'deepseek') {
      return this.callOpenAICompatible({
        endpoint: 'https://api.deepseek.com/chat/completions',
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    if (providerId === 'mistral') {
      return this.callOpenAICompatible({
        endpoint: 'https://api.mistral.ai/v1/chat/completions',
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    if (providerId === 'openrouter') {
      return this.callOpenAICompatible({
        endpoint: 'https://openrouter.ai/api/v1/chat/completions',
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    if (providerId === 'custom') {
      const url = baseUrl || 'http://localhost:11434/v1';
      const endpoint = url.endsWith('/chat/completions') ? url : `${url.replace(/\/$/, '')}/chat/completions`;
      return this.callOpenAICompatible({
        endpoint,
        apiKey,
        modelId,
        messages,
        temperature,
        max_tokens,
      });
    }

    throw new Error(`Unsupported provider: ${providerId}`);
  }

  /**
   * Native Google Gemini using @google/genai SDK
   */
  private async callGeminiDirect(
    apiKey: string,
    modelId: string,
    messages: ChatMessage[],
    temperature?: number
  ): Promise<{ content: string; promptTokens: number; completionTokens: number }> {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Extract system instructions and format contents
    const systemMsg = messages.find(m => m.role === 'system');
    const userAndAssistantMsgs = messages.filter(m => m.role !== 'system');

    // Build contents string or parts
    const promptText = userAndAssistantMsgs.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n\n');

    const config: { systemInstruction?: string; temperature?: number } = {};
    if (systemMsg) {
      config.systemInstruction = systemMsg.content;
    }
    if (temperature !== undefined) {
      config.temperature = temperature;
    }

    const response = await ai.models.generateContent({
      model: modelId || 'gemini-3.8-flash',
      contents: promptText || 'Hello',
      config,
    });

    const text = response.text || '';
    const promptTokens = Math.ceil(promptText.length / 4);
    const completionTokens = Math.ceil(text.length / 4);

    return {
      content: text,
      promptTokens,
      completionTokens,
    };
  }

  /**
   * Standard OpenAI-compatible HTTP fetch caller
   */
  private async callOpenAICompatible(params: {
    endpoint: string;
    apiKey: string;
    modelId: string;
    messages: ChatMessage[];
    temperature?: number;
    max_tokens?: number;
  }): Promise<{ content: string; promptTokens: number; completionTokens: number }> {
    const { endpoint, apiKey, modelId, messages, temperature, max_tokens } = params;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 18000);

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: modelId,
          messages,
          temperature: temperature ?? 0.7,
          max_tokens: max_tokens ?? 2048,
        }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const errorText = await res.text();
        let message = `HTTP ${res.status}: ${res.statusText}`;
        try {
          const parsed = JSON.parse(errorText);
          if (parsed.error?.message) {
            message = parsed.error.message;
          }
        } catch {
          if (errorText) message += ` - ${errorText.slice(0, 120)}`;
        }
        const err = new Error(message);
        (err as { status?: number }).status = res.status;
        throw err;
      }

      const data = await res.json();
      const content = data.choices?.[0]?.message?.content || '';
      const promptTokens = data.usage?.prompt_tokens || 0;
      const completionTokens = data.usage?.completion_tokens || 0;

      return { content, promptTokens, completionTokens };
    } finally {
      clearTimeout(timeout);
    }
  }

  /**
   * Anthropic Claude Messages API
   */
  private async callAnthropic(params: {
    apiKey: string;
    modelId: string;
    messages: ChatMessage[];
    temperature?: number;
    max_tokens?: number;
  }): Promise<{ content: string; promptTokens: number; completionTokens: number }> {
    const { apiKey, modelId, messages, temperature, max_tokens } = params;

    const systemMsg = messages.find(m => m.role === 'system');
    const conversation = messages
      .filter(m => m.role !== 'system')
      .map(m => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: m.content,
      }));

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: modelId,
          messages: conversation,
          system: systemMsg?.content,
          max_tokens: max_tokens ?? 2048,
          temperature: temperature ?? 0.7,
        }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const errorText = await res.text();
        const err = new Error(`Anthropic error (${res.status}): ${errorText.slice(0, 140)}`);
        (err as { status?: number }).status = res.status;
        throw err;
      }

      const data = await res.json();
      const text = data.content?.[0]?.text || '';
      return {
        content: text,
        promptTokens: data.usage?.input_tokens || 0,
        completionTokens: data.usage?.output_tokens || 0,
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  /**
   * Ping / Health test a specific provider key
   */
  public async testProviderConnection(providerId: ProviderType): Promise<{
    ok: boolean;
    latencyMs: number;
    message: string;
    modelTested: string;
  }> {
    const provider = this.providers.get(providerId);
    if (!provider) {
      return { ok: false, latencyMs: 0, message: 'Provider not found', modelTested: '' };
    }

    const effectiveKey = provider.apiKey || (providerId === 'gemini' ? process.env.GEMINI_API_KEY : '');
    if (!effectiveKey) {
      return {
        ok: false,
        latencyMs: 0,
        message: 'No API key configured for this provider',
        modelTested: provider.models[0]?.id || '',
      };
    }

    const testModel = provider.models[0]?.id || '';
    const startTime = Date.now();

    try {
      await this.callProviderModel({
        providerId,
        modelId: testModel,
        apiKey: effectiveKey,
        baseUrl: provider.baseUrl,
        messages: [{ role: 'user', content: 'ping' }],
        max_tokens: 5,
      });

      const latencyMs = Date.now() - startTime;
      provider.status = 'healthy';
      provider.latencyMs = latencyMs;
      provider.lastChecked = Date.now();

      return {
        ok: true,
        latencyMs,
        message: `Successfully connected to ${provider.name}. Latency: ${latencyMs}ms`,
        modelTested: testModel,
      };
    } catch (err: unknown) {
      const latencyMs = Date.now() - startTime;
      const errMsg = err instanceof Error ? err.message : String(err);
      provider.status = errMsg.includes('429')
        ? 'rate-limited'
        : errMsg.includes('402')
        ? 'quota-exceeded'
        : 'invalid-key';
      provider.latencyMs = latencyMs;

      return {
        ok: false,
        latencyMs,
        message: errMsg,
        modelTested: testModel,
      };
    }
  }
}

export const gatewayEngine = new GatewayEngine();
