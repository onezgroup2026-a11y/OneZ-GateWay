export type ProviderType = 
  | 'gemini'
  | 'groq'
  | 'openai'
  | 'anthropic'
  | 'deepseek'
  | 'mistral'
  | 'openrouter'
  | 'custom';

export interface ProviderModel {
  id: string;
  name: string;
  provider: ProviderType;
  contextWindow: number;
  speed: 'ultra-fast' | 'fast' | 'balanced' | 'deep';
  costTier: 'free' | 'low' | 'medium' | 'high';
  strengths: string[];
}

export interface ProviderConfig {
  id: ProviderType;
  name: string;
  enabled: boolean;
  apiKey: string;
  hasEnvKey?: boolean;
  baseUrl?: string;
  status: 'healthy' | 'rate-limited' | 'quota-exceeded' | 'invalid-key' | 'disabled';
  latencyMs?: number;
  lastChecked?: number;
  models: ProviderModel[];
  simulateFailover?: boolean; // For testing automatic failover behavior
  simulateErrorType?: '429-rate-limit' | '402-quota-exhausted' | '503-server-error' | 'timeout';
}

export interface CascadeStep {
  providerId: ProviderType;
  modelId: string;
  label?: string;
}

export interface ModelCombo {
  id: string;
  name: string;
  slug: string; // The model ID sent in API requests, e.g. "onez-ultra-fast"
  description: string;
  icon?: string;
  cascade: CascadeStep[];
  routingStrategy: 'priority-cascade' | 'fastest-race' | 'smart-intent';
  failoverTriggers: {
    onRateLimit: boolean;      // 429
    onQuotaExceeded: boolean;  // 402 or balance zero
    onServerError: boolean;    // 500, 502, 503, 504
    onTimeout: boolean;        // Request timeout
    onAuthError: boolean;      // 401/403
    timeoutMs: number;
  };
  isSystem?: boolean;
}

export interface SmartIntentRoute {
  category: 'code' | 'reasoning' | 'fast_chat' | 'creative' | 'general';
  label: string;
  description: string;
  keywords: string[];
  preferredComboId: string;
}

export interface FailoverEvent {
  stepIndex: number;
  providerId: ProviderType;
  modelId: string;
  errorReason: string;
  statusCode?: number;
  timestamp: number;
  latencyMs: number;
}

export interface GatewayRequestLog {
  id: string;
  timestamp: number;
  clientIp?: string;
  requestedModel: string;
  actualProvider: ProviderType;
  actualModel: string;
  status: 'success' | 'failed' | 'recovered_via_failover';
  promptPreview: string;
  responsePreview?: string;
  latencyMs: number;
  tokens: {
    prompt: number;
    completion: number;
    total: number;
  };
  failovers: FailoverEvent[];
  streaming: boolean;
}

export interface GatewayStats {
  totalRequests: number;
  successRate: number;
  failoversRecovered: number;
  avgLatencyMs: number;
  totalTokens: number;
  uptimeHours: number;
  activeProviders: number;
  activeCombos: number;
}
