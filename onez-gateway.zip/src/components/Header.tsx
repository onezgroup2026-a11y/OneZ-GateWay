import React from 'react';
import { 
  Zap, 
  ShieldCheck, 
  Cpu, 
  ArrowRightLeft, 
  Activity, 
  Copy, 
  Check, 
  Sparkles,
  Terminal
} from 'lucide-react';
import { GatewayStats } from '../types/gateway';

interface HeaderProps {
  stats: GatewayStats;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  appUrl: string;
}

export const Header: React.FC<HeaderProps> = ({ stats, activeTab, setActiveTab, appUrl }) => {
  const [copied, setCopied] = React.useState(false);

  const copyEndpoint = () => {
    const endpoint = `${window.location.origin}/api/v1/chat/completions`;
    navigator.clipboard.writeText(endpoint);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const navItems = [
    { id: 'playground', label: 'Gateway Studio', icon: Terminal, badge: 'Live' },
    { id: 'combos', label: 'Model Combos', icon: Cpu, badge: `${stats.activeCombos}` },
    { id: 'router', label: 'Smart Auto-Router', icon: ArrowRightLeft },
    { id: 'providers', label: 'Provider Vault', icon: ShieldCheck, badge: `${stats.activeProviders} Active` },
    { id: 'integration', label: 'API & Integrations', icon: Zap },
    { id: 'logs', label: 'Traffic Logs', icon: Activity, badge: `${stats.totalRequests}` },
  ];

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40">
      {/* Top Banner with Brand and Gateway Status */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-indigo-600 to-fuchsia-600 p-[1px] shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full bg-zinc-950 rounded-xl flex items-center justify-center">
                <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  OneZ <span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">GateWay</span>
                </h1>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-400 border border-cyan-800/60 font-medium">
                  v2.4 Zero-Downtime
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Universal AI Aggregator & Automatic Credit/Token Failover Switch
              </p>
            </div>
          </div>

          {/* Quick Metrics Bar & Endpoint Copy */}
          <div className="flex items-center flex-wrap gap-2.5">
            {/* Live Uptime */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span className="text-zinc-400">Uptime:</span>
              </div>
              <span className="font-mono font-semibold text-emerald-400">99.99%</span>
            </div>

            {/* Failover Shield Counter */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-zinc-400">Failovers Saved:</span>
              <span className="font-mono font-semibold text-cyan-300">{stats.failoversRecovered}</span>
            </div>

            {/* Avg Latency */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs">
              <Activity className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-zinc-400">Avg Latency:</span>
              <span className="font-mono font-semibold text-amber-300">{stats.avgLatencyMs}ms</span>
            </div>

            {/* Copy API Base URL */}
            <button
              onClick={copyEndpoint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 text-xs font-mono transition-colors shadow-sm"
              title="Copy OpenAI-compatible API endpoint"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied Endpoint!' : 'Copy /v1/chat API'}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 mt-4 overflow-x-auto pb-1 scrollbar-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-zinc-800 text-cyan-300 shadow-sm border border-zinc-700/80'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-zinc-500'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-md font-mono ${
                      isActive
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
