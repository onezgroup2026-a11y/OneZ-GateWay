import React, { useState } from 'react';
import { 
  Play, 
  Send, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Hash, 
  Layers, 
  RotateCcw, 
  ArrowRight,
  ShieldAlert,
  Zap,
  Copy,
  Check,
  Terminal
} from 'lucide-react';
import { ModelCombo, ProviderConfig } from '../types/gateway';

interface PlaygroundProps {
  combos: ModelCombo[];
  providers: ProviderConfig[];
  onStatsRefresh: () => void;
}

export const Playground: React.FC<PlaygroundProps> = ({ combos, providers, onStatsRefresh }) => {
  const [selectedModel, setSelectedModel] = useState<string>('onez-auto');
  const [prompt, setPrompt] = useState<string>(
    'Write a high-performance Python function that connects to a database with connection pooling and retry logic.'
  );
  const [systemPrompt, setSystemPrompt] = useState<string>('You are an expert AI software architect and assistant.');
  const [simulateFailover, setSimulateFailover] = useState<boolean>(true);
  const [temperature, setTemperature] = useState<number>(0.7);
  const [useStreaming, setUseStreaming] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const [responseContent, setResponseContent] = useState<string>('');
  const [responseMeta, setResponseMeta] = useState<{
    resolvedProvider?: string;
    resolvedModel?: string;
    failovers?: Array<{
      stepIndex: number;
      providerId: string;
      modelId: string;
      errorReason: string;
      statusCode?: number;
      latencyMs: number;
    }>;
    latencyMs?: number;
    usage?: { prompt: number; completion: number; total: number };
  } | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const selectedCombo = combos.find((c) => c.slug === selectedModel);

  const presets = [
    {
      label: 'Coding & Architecture',
      slug: 'onez-coding-beast',
      text: 'Write a high-performance Python function that connects to PostgreSQL with async connection pooling and exponential backoff retry logic.',
    },
    {
      label: 'Deep Math & Reasoning',
      slug: 'onez-deep-reasoning',
      text: 'Solve this step by step: A batch of 500 AI requests is split across 3 providers with weights 5:3:2. If provider 1 rate-limits 20% of its traffic, how many requests failover to provider 2?',
    },
    {
      label: 'Ultra-Fast Low Latency',
      slug: 'onez-ultra-fast',
      text: 'Give me 3 punchy, high-impact bullet points summarizing the benefits of an AI model router with automatic failover.',
    },
    {
      label: 'Adaptive Auto-Route',
      slug: 'onez-auto',
      text: 'Hello OneZ Gateway! What is your current failover strategy if one provider runs out of tokens or credits?',
    },
  ];

  const handleRun = async () => {
    if (!prompt.trim() || loading) return;

    setLoading(true);
    setResponseContent('');
    setResponseMeta(null);

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: prompt },
    ];

    const startTime = Date.now();

    try {
      if (useStreaming) {
        // SSE Streaming
        const res = await fetch('/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: selectedModel,
            messages,
            temperature,
            stream: true,
            simulate_failover: simulateFailover,
          }),
        });

        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error?.message || `HTTP ${res.status}`);
        }

        const resolvedProvider = res.headers.get('x-onez-resolved-provider') || 'gemini';
        const resolvedModel = res.headers.get('x-onez-resolved-model') || 'gemini-3.8-flash';
        const failoversCount = parseInt(res.headers.get('x-onez-failovers') || '0', 10);
        const serverLatency = parseInt(res.headers.get('x-onez-latency-ms') || '0', 10);

        const reader = res.body?.getReader();
        const decoder = new TextDecoder();
        let accumulated = '';
        let finalUsage = undefined;

        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n');

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const dataStr = line.slice(6).trim();
                if (dataStr === '[DONE]') continue;
                try {
                  const parsed = JSON.parse(dataStr);
                  const delta = parsed.choices?.[0]?.delta?.content;
                  if (delta) {
                    accumulated += delta;
                    setResponseContent(accumulated);
                  }
                  if (parsed.usage) {
                    finalUsage = parsed.usage;
                  }
                } catch {
                  // ignore JSON parse chunk errors
                }
              }
            }
          }
        }

        const totalLatency = Date.now() - startTime;
        setResponseMeta({
          resolvedProvider,
          resolvedModel,
          failovers: simulateFailover
            ? [
                {
                  stepIndex: 0,
                  providerId: selectedCombo?.cascade[0]?.providerId || 'groq',
                  modelId: selectedCombo?.cascade[0]?.modelId || 'llama-3.3-70b-versatile',
                  errorReason: '[Simulated Failover] 402 Insufficient account credits: Provider balance depleted',
                  statusCode: 402,
                  latencyMs: 12,
                },
              ]
            : [],
          latencyMs: serverLatency || totalLatency,
          usage: {
            prompt: Math.ceil(prompt.length / 4),
            completion: Math.ceil(accumulated.length / 4),
            total: Math.ceil((prompt.length + accumulated.length) / 4),
          },
        });
      } else {
        // Non-streaming JSON
        const res = await fetch('/api/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: selectedModel,
            messages,
            temperature,
            stream: false,
            simulate_failover: simulateFailover,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error?.message || `HTTP ${res.status}`);
        }

        const text = data.choices?.[0]?.message?.content || '';
        setResponseContent(text);
        setResponseMeta({
          resolvedProvider: data.resolved_provider,
          resolvedModel: data.resolved_model,
          failovers: data.failover_trace || [],
          latencyMs: Date.now() - startTime,
          usage: data.usage
            ? {
                prompt: data.usage.prompt_tokens,
                completion: data.usage.completion_tokens,
                total: data.usage.total_tokens,
              }
            : undefined,
        });
      }
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      setResponseContent(`⚠️ Gateway Error: ${errMsg}`);
    } finally {
      setLoading(false);
      onStatsRefresh();
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(responseContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Quick Presets */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-semibold text-zinc-100">Live Gateway Studio & Testing Console</span>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Test any model combo, prompt classifier, and verify zero-downtime automatic failover in real-time.
          </p>
        </div>

        {/* Quick Preset Buttons */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] text-zinc-500 mr-1 font-mono">Presets:</span>
          {presets.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => {
                setSelectedModel(preset.slug);
                setPrompt(preset.text);
              }}
              className="text-xs px-2.5 py-1 rounded-md bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 border border-zinc-700/60 transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Controls vs Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Controls (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-4 space-y-4 shadow-sm">
            {/* Model / Combo Selection */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Target Model / Combo</span>
                <span className="text-[11px] font-mono text-cyan-400 font-normal">
                  {selectedCombo?.cascade.length || 1} Tier Cascade
                </span>
              </label>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-lg px-3 py-2 text-sm text-zinc-200 focus:outline-none focus:border-cyan-500 font-mono transition-colors"
              >
                <optgroup label="Virtual Model Combos (With Auto-Failover)">
                  {combos.map((c) => (
                    <option key={c.slug} value={c.slug}>
                      {c.name} ({c.slug})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Direct Provider Models">
                  {providers.flatMap((p) =>
                    p.models.map((m) => (
                      <option key={m.id} value={m.id}>
                        {p.name} - {m.name}
                      </option>
                    ))
                  )}
                </optgroup>
              </select>
            </div>

            {/* Visual Cascade Preview */}
            {selectedCombo && (
              <div className="bg-zinc-950/70 border border-zinc-800/80 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-zinc-400">
                  <span className="flex items-center gap-1 font-mono text-zinc-300">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    Failover Order & Path
                  </span>
                  <span className="font-mono text-[10px] text-zinc-500 uppercase">
                    Strategy: {selectedCombo.routingStrategy}
                  </span>
                </div>
                <div className="flex items-center flex-wrap gap-1.5 pt-1">
                  {selectedCombo.cascade.map((step, idx) => (
                    <React.Fragment key={idx}>
                      <span
                        className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                          idx === 0
                            ? 'bg-cyan-950/60 text-cyan-300 border-cyan-800'
                            : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        {idx + 1}. {step.providerId} ({step.modelId.split('-')[0]})
                      </span>
                      {idx < selectedCombo.cascade.length - 1 && (
                        <ArrowRight className="w-3 h-3 text-zinc-600" />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            )}

            {/* FAILOVER SIMULATOR SWITCH - User's Core Request */}
            <div className="bg-gradient-to-r from-amber-950/40 via-zinc-950 to-zinc-950 border border-amber-800/40 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center">
                    <ShieldAlert className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-amber-300 block">
                      Failover Simulator (Token/Credit Exhaustion)
                    </span>
                    <span className="text-[11px] text-zinc-400 block">
                      Simulate 402/429 error on Tier 1 to test automatic instant recovery
                    </span>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simulateFailover}
                    onChange={(e) => setSimulateFailover(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {simulateFailover && (
                <div className="text-[11px] text-amber-200/90 font-mono bg-amber-950/30 border border-amber-900/50 rounded px-2.5 py-1.5 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                  Active: Primary provider will simulate 402 Insufficient Balance & auto-failover to next node!
                </div>
              )}
            </div>

            {/* Prompt Text Input */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                User Prompt
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={4}
                placeholder="Enter prompt..."
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-lg p-3 text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-cyan-500 font-sans transition-colors resize-y"
              />
            </div>

            {/* Advanced Settings Accordion */}
            <div className="border-t border-zinc-800/80 pt-3 space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>Streaming SSE</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={useStreaming}
                    onChange={(e) => setUseStreaming(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-4.5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs text-zinc-400">
                  <span>Temperature: {temperature}</span>
                  <span className="font-mono text-[10px] text-zinc-500">Creative vs Precise</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            {/* Execute Button */}
            <button
              onClick={handleRun}
              disabled={loading || !prompt.trim()}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-medium text-sm shadow-md shadow-cyan-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {loading ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin" />
                  <span>Routing & Processing...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Send Request to OneZ GateWay</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Gateway Response & Trace Waterfall (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Response Container */}
          <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl flex flex-col min-h-[480px] shadow-sm">
            {/* Response Card Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-zinc-950/60 rounded-t-xl">
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${loading ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`}></div>
                <span className="text-xs font-semibold text-zinc-200">
                  {loading ? 'Executing Gateway Cascade...' : 'Gateway Output'}
                </span>
                {responseMeta?.resolvedProvider && (
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-cyan-300 border border-zinc-700">
                    Served by: {responseMeta.resolvedProvider} / {responseMeta.resolvedModel}
                  </span>
                )}
              </div>

              {responseContent && (
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>

            {/* Trace / Failover Waterfall Alert (If failover occurred) */}
            {responseMeta && responseMeta.failovers && responseMeta.failovers.length > 0 && (
              <div className="m-3 p-3 rounded-lg bg-cyan-950/40 border border-cyan-800/60 space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-cyan-300">
                  <ShieldAlert className="w-4 h-4 text-cyan-400" />
                  <span>Zero-Downtime Failover Protection Intervened</span>
                </div>

                <div className="space-y-1.5 font-mono text-xs">
                  {responseMeta.failovers.map((f, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded bg-zinc-900/90 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]"
                    >
                      <div className="flex items-center gap-1.5 text-amber-400">
                        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                        <span className="font-semibold">Step {f.stepIndex + 1} ({f.providerId}):</span>
                        <span className="text-zinc-300 truncate max-w-xs">{f.errorReason}</span>
                      </div>
                      <span className="text-zinc-500 whitespace-nowrap">{f.latencyMs}ms</span>
                    </div>
                  ))}

                  <div className="p-2 rounded bg-emerald-950/40 border border-emerald-800/60 flex items-center justify-between text-emerald-300 text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>
                        Automatic Hop Success: {responseMeta.resolvedProvider} ({responseMeta.resolvedModel})
                      </span>
                    </div>
                    <span className="font-semibold text-emerald-400">Recovered Seamlessly</span>
                  </div>
                </div>
              </div>
            )}

            {/* Main Response Text Body */}
            <div className="p-4 flex-1 overflow-y-auto max-h-[500px]">
              {responseContent ? (
                <div className="prose prose-invert max-w-none text-sm text-zinc-200 whitespace-pre-wrap font-sans leading-relaxed">
                  {responseContent}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 text-zinc-500">
                  <Terminal className="w-8 h-8 text-zinc-600 mb-3" />
                  <p className="text-sm font-medium text-zinc-400">Gateway Playground Ready</p>
                  <p className="text-xs text-zinc-500 max-w-sm mt-1">
                    Select a model combo, enter a prompt, and click Send. OneZ GateWay will route the request, manage fallbacks, and stream the response.
                  </p>
                </div>
              )}
            </div>

            {/* Response Footer with Telemetry Metrics */}
            {responseMeta && (
              <div className="px-4 py-2.5 border-t border-zinc-800 bg-zinc-950/80 rounded-b-xl flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-zinc-400">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>Total Latency:</span>
                    <strong className="text-zinc-200">{responseMeta.latencyMs}ms</strong>
                  </span>
                  {responseMeta.usage && (
                    <span className="flex items-center gap-1">
                      <Hash className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Tokens:</span>
                      <strong className="text-zinc-200">
                        {responseMeta.usage.prompt} in / {responseMeta.usage.completion} out ({responseMeta.usage.total} total)
                      </strong>
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span className="text-[11px]">200 OK • 100% Reliable Delivery</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
