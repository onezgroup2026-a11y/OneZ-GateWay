import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  MoveUp, 
  MoveDown, 
  Layers, 
  Cpu, 
  ShieldCheck, 
  Zap, 
  Check, 
  Clock, 
  Sparkles, 
  Info,
  Sliders,
  Copy
} from 'lucide-react';
import { ModelCombo, ProviderConfig, CascadeStep, ProviderType } from '../types/gateway';

interface CombosManagerProps {
  combos: ModelCombo[];
  providers: ProviderConfig[];
  onSaveCombo: (combo: ModelCombo) => Promise<void>;
  onDeleteCombo: (slug: string) => Promise<void>;
  onTestCombo: (slug: string) => void;
}

export const CombosManager: React.FC<CombosManagerProps> = ({
  combos,
  providers,
  onSaveCombo,
  onDeleteCombo,
  onTestCombo,
}) => {
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState<string>('');
  const [slug, setSlug] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [routingStrategy, setRoutingStrategy] = useState<'priority-cascade' | 'fastest-race' | 'smart-intent'>('priority-cascade');
  const [timeoutMs, setTimeoutMs] = useState<number>(10000);
  const [cascade, setCascade] = useState<CascadeStep[]>([
    { providerId: 'gemini', modelId: 'gemini-3.8-flash', label: 'Primary Engine' },
    { providerId: 'groq', modelId: 'llama-3.3-70b-versatile', label: 'Fast Fallback' },
  ]);

  const addCascadeStep = () => {
    setCascade([
      ...cascade,
      { providerId: 'gemini', modelId: 'gemini-3.8-flash', label: `Tier ${cascade.length + 1} Fallback` },
    ]);
  };

  const removeCascadeStep = (index: number) => {
    if (cascade.length <= 1) return;
    setCascade(cascade.filter((_, i) => i !== index));
  };

  const moveStep = (index: number, direction: 'up' | 'down') => {
    const newIdx = direction === 'up' ? index - 1 : index + 1;
    if (newIdx < 0 || newIdx >= cascade.length) return;
    const updated = [...cascade];
    const temp = updated[index];
    updated[index] = updated[newIdx];
    updated[newIdx] = temp;
    setCascade(updated);
  };

  const updateStepProvider = (index: number, providerId: ProviderType) => {
    const provider = providers.find((p) => p.id === providerId);
    const defaultModel = provider?.models[0]?.id || '';
    const updated = [...cascade];
    updated[index] = {
      ...updated[index],
      providerId,
      modelId: defaultModel,
    };
    setCascade(updated);
  };

  const updateStepModel = (index: number, modelId: string) => {
    const updated = [...cascade];
    updated[index] = {
      ...updated[index],
      modelId,
    };
    setCascade(updated);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !slug.trim() || cascade.length === 0) return;

    const formattedSlug = slug.toLowerCase().replace(/[^a-z0-9_-]/g, '-');
    const newCombo: ModelCombo = {
      id: `combo-${Date.now()}`,
      name,
      slug: formattedSlug,
      description: description || `Custom AI Model Combo with ${cascade.length} failover tiers.`,
      routingStrategy,
      cascade,
      failoverTriggers: {
        onRateLimit: true,
        onQuotaExceeded: true,
        onServerError: true,
        onTimeout: true,
        onAuthError: true,
        timeoutMs,
      },
      isSystem: false,
    };

    await onSaveCombo(newCombo);
    setShowCreateModal(false);
    setName('');
    setSlug('');
    setDescription('');
  };

  const copySlug = (s: string) => {
    navigator.clipboard.writeText(s);
    setCopiedSlug(s);
    setTimeout(() => setCopiedSlug(null), 1500);
  };

  return (
    <div className="space-y-6">
      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <span>Virtual Model Combos & Cascades</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Group multiple AI providers and models into a single virtual model name (e.g.{' '}
            <code className="text-cyan-300 font-mono">onez-ultra-fast</code>). If a provider runs out of tokens or credits, OneZ automatically hops to the next in real-time.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white rounded-lg text-xs font-semibold shadow-md shadow-cyan-500/20 transition-all whitespace-nowrap self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Combo</span>
        </button>
      </div>

      {/* Combos Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {combos.map((combo) => (
          <div
            key={combo.slug}
            className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 flex flex-col justify-between hover:border-zinc-700 transition-all shadow-sm space-y-4"
          >
            <div className="space-y-3">
              {/* Card Title & Badge */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-sm text-zinc-100">{combo.name}</h3>
                    {combo.isSystem && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">
                        Standard
                      </span>
                    )}
                  </div>
                  {/* Model Slug for API Calling */}
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/80 px-2 py-0.5 rounded">
                      model: "{combo.slug}"
                    </span>
                    <button
                      onClick={() => copySlug(combo.slug)}
                      className="text-zinc-500 hover:text-zinc-300 p-1 transition-colors"
                      title="Copy Model Slug"
                    >
                      {copiedSlug === combo.slug ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <p className="text-xs text-zinc-400 line-clamp-2">{combo.description}</p>

              {/* Cascade Tiers Visual List */}
              <div className="space-y-1.5 pt-2 border-t border-zinc-800/60">
                <span className="text-[11px] font-mono text-zinc-500 uppercase flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Failover Chain ({combo.cascade.length} Tiers):
                </span>
                <div className="space-y-1">
                  {combo.cascade.map((step, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs px-2.5 py-1.5 rounded bg-zinc-950/60 border border-zinc-800 font-mono"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${
                          idx === 0 ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'bg-zinc-800 text-zinc-400'
                        }`}>
                          {idx + 1}
                        </span>
                        <span className="text-zinc-300 font-medium capitalize">{step.providerId}</span>
                        <span className="text-zinc-500 text-[11px] truncate">({step.modelId})</span>
                      </div>
                      {idx === 0 ? (
                        <span className="text-[10px] text-cyan-400 uppercase font-semibold">Primary</span>
                      ) : (
                        <span className="text-[10px] text-zinc-500 uppercase">Tier {idx + 1}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Strategy & Trigger Badges */}
              <div className="flex items-center flex-wrap gap-1.5 pt-1 text-[10px] font-mono text-zinc-400">
                <span className="px-2 py-0.5 rounded bg-zinc-800/80 border border-zinc-700/60">
                  Strategy: {combo.routingStrategy}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-950/40 text-emerald-400 border border-emerald-900/60">
                  Zero-Downtime on 402/429
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
              <button
                onClick={() => onTestCombo(combo.slug)}
                className="text-xs px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-cyan-300 font-medium transition-colors flex items-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>Test in Studio</span>
              </button>

              {!combo.isSystem && (
                <button
                  onClick={() => onDeleteCombo(combo.slug)}
                  className="text-xs p-1.5 rounded-lg text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition-colors"
                  title="Delete Custom Combo"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Create Combo Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-base text-white">Create New Model Combo</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-zinc-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1">
                  Combo Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Production High-Speed Tier"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (!slug) {
                      setSlug(e.target.value.toLowerCase().replace(/\s+/g, '-'));
                    }
                  }}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2.5 text-sm text-zinc-200 focus:outline-none focus:border-cyan-500 font-sans"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1">
                  API Model Slug (Call this in your code / API)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. onez-prod-fast"
                  value={slug}
                  onChange={(e) => setSlug(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2.5 text-sm text-cyan-400 font-mono focus:outline-none focus:border-cyan-500"
                />
                <p className="text-[11px] text-zinc-500 mt-1">
                  This will be the model identifier you pass to <code className="text-zinc-400">/api/v1/chat/completions</code>.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  placeholder="What is this combo optimized for?"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2.5 text-sm text-zinc-200 focus:outline-none focus:border-cyan-500 font-sans"
                />
              </div>

              {/* Cascade Steps Builder */}
              <div className="space-y-2 border-t border-zinc-800 pt-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
                    Failover Cascade Order (Top = Primary)
                  </label>
                  <button
                    type="button"
                    onClick={addCascadeStep}
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Tier</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {cascade.map((step, idx) => {
                    const currentProvider = providers.find((p) => p.id === step.providerId);
                    return (
                      <div
                        key={idx}
                        className="flex items-center gap-2 bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs"
                      >
                        <span className="font-mono text-zinc-500 font-bold px-1.5">{idx + 1}</span>

                        {/* Provider Select */}
                        <select
                          value={step.providerId}
                          onChange={(e) => updateStepProvider(idx, e.target.value as ProviderType)}
                          className="bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-zinc-200 text-xs font-medium focus:outline-none"
                        >
                          {providers.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name}
                            </option>
                          ))}
                        </select>

                        {/* Model Select */}
                        <select
                          value={step.modelId}
                          onChange={(e) => updateStepModel(idx, e.target.value)}
                          className="flex-1 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-zinc-200 text-xs font-mono focus:outline-none truncate"
                        >
                          {currentProvider?.models.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>

                        {/* Reorder Buttons */}
                        <div className="flex items-center gap-0.5">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => moveStep(idx, 'up')}
                            className="p-1 text-zinc-400 hover:text-zinc-200 disabled:opacity-30"
                          >
                            <MoveUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={idx === cascade.length - 1}
                            onClick={() => moveStep(idx, 'down')}
                            className="p-1 text-zinc-400 hover:text-zinc-200 disabled:opacity-30"
                          >
                            <MoveDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={cascade.length <= 1}
                            onClick={() => removeCascadeStep(idx)}
                            className="p-1 text-rose-400 hover:text-rose-300 disabled:opacity-30"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Strategy */}
              <div className="grid grid-cols-2 gap-3 border-t border-zinc-800 pt-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1">
                    Routing Strategy
                  </label>
                  <select
                    value={routingStrategy}
                    onChange={(e) => setRoutingStrategy(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2 text-xs text-zinc-200"
                  >
                    <option value="priority-cascade">Priority Cascade (Sequential)</option>
                    <option value="fastest-race">Fastest First (Low Latency)</option>
                    <option value="smart-intent">Smart Intent Guided</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1">
                    Step Timeout (ms)
                  </label>
                  <input
                    type="number"
                    value={timeoutMs}
                    onChange={(e) => setTimeoutMs(parseInt(e.target.value, 10))}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2 text-xs text-zinc-200 font-mono"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-cyan-500/20"
                >
                  Save & Register Model Combo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
