import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Key, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  RotateCcw, 
  ExternalLink,
  Flame,
  Zap,
  Sliders,
  Server,
  Layers
} from 'lucide-react';
import { ProviderConfig, ProviderType } from '../types/gateway';

interface ProviderVaultProps {
  providers: ProviderConfig[];
  onUpdateProvider: (id: ProviderType, updates: Partial<ProviderConfig>) => Promise<void>;
  onTestProvider: (id: ProviderType) => Promise<{ ok: boolean; latencyMs: number; message: string }>;
}

export const ProviderVault: React.FC<ProviderVaultProps> = ({
  providers,
  onUpdateProvider,
  onTestProvider,
}) => {
  const [editingKeys, setEditingKeys] = useState<{ [key: string]: string }>({});
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<{
    [key: string]: { ok: boolean; latencyMs: number; message: string };
  }>({});

  const handleKeyChange = (providerId: string, val: string) => {
    setEditingKeys({ ...editingKeys, [providerId]: val });
  };

  const handleSaveKey = async (provider: ProviderConfig) => {
    const newKey = editingKeys[provider.id];
    if (newKey === undefined) return;
    await onUpdateProvider(provider.id, { apiKey: newKey });
    setEditingKeys({ ...editingKeys, [provider.id]: '' });
  };

  const handleTest = async (providerId: ProviderType) => {
    setTestingId(providerId);
    try {
      const res = await onTestProvider(providerId);
      setTestResults((prev) => ({ ...prev, [providerId]: res }));
    } finally {
      setTestingId(null);
    }
  };

  const getStatusBadge = (provider: ProviderConfig) => {
    if (!provider.enabled) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
          Disabled
        </span>
      );
    }
    if (provider.simulateFailover) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/70 text-amber-300 border border-amber-800 animate-pulse">
          Simulating Depletion ({provider.simulateErrorType || '402'})
        </span>
      );
    }
    if (provider.hasEnvKey || provider.apiKey) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-800 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          Ready & Healthy ({provider.latencyMs || 250}ms)
        </span>
      );
    }
    return (
      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-900 text-zinc-500 border border-zinc-800">
        Needs API Key
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <span>AI Provider Vault & Key Management</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Store and manage API keys for major AI providers. When any provider runs out of credits or encounters 429 rate limits, OneZ GateWay immediately transfers the request to backup providers without dropping traffic.
          </p>
        </div>
      </div>

      {/* Providers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {providers.map((provider) => {
          const isTesting = testingId === provider.id;
          const testRes = testResults[provider.id];
          const hasKey = provider.hasEnvKey || !!provider.apiKey;

          return (
            <div
              key={provider.id}
              className={`bg-zinc-900/90 border rounded-xl p-5 space-y-4 transition-all shadow-sm ${
                provider.simulateFailover
                  ? 'border-amber-700/60 bg-amber-950/10'
                  : 'border-zinc-800 hover:border-zinc-700'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-sm text-zinc-100">{provider.name}</h3>
                    {getStatusBadge(provider)}
                  </div>
                  <span className="text-[11px] font-mono text-zinc-500 uppercase">
                    ID: {provider.id} • {provider.models.length} Models Supported
                  </span>
                </div>

                {/* Enable/Disable Toggle */}
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={provider.enabled}
                    onChange={(e) => onUpdateProvider(provider.id, { enabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-4.5 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-cyan-500"></div>
                </label>
              </div>

              {/* API Key Input / Status */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                  <span>API Key</span>
                  {provider.hasEnvKey && (
                    <span className="text-[10px] text-emerald-400 font-mono">
                      ✓ Injected from Server Environment
                    </span>
                  )}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="password"
                    placeholder={hasKey ? (provider.apiKey ? provider.apiKey : '••••••••••••••••') : `Enter ${provider.name} API Key`}
                    value={editingKeys[provider.id] !== undefined ? editingKeys[provider.id] : ''}
                    onChange={(e) => handleKeyChange(provider.id, e.target.value)}
                    className="flex-1 bg-zinc-950 border border-zinc-700/80 rounded-lg px-3 py-1.5 text-xs text-zinc-200 font-mono placeholder-zinc-600 focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={() => handleSaveKey(provider)}
                    disabled={!editingKeys[provider.id]}
                    className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium disabled:opacity-40 transition-colors"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => handleTest(provider.id)}
                    disabled={isTesting || (!hasKey && !editingKeys[provider.id])}
                    className="px-3 py-1.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-800/80 text-cyan-300 text-xs font-medium disabled:opacity-40 transition-colors flex items-center gap-1"
                    title="Ping Connection Benchmark"
                  >
                    {isTesting ? <RotateCcw className="w-3.5 h-3.5 animate-spin" /> : <Activity className="w-3.5 h-3.5" />}
                    <span>Test Ping</span>
                  </button>
                </div>

                {/* Custom Base URL (For Custom Provider) */}
                {provider.id === 'custom' && (
                  <div className="pt-2">
                    <label className="text-xs font-mono text-zinc-400 block mb-1">
                      Endpoint Base URL (Ollama, vLLM, LMStudio, Together AI)
                    </label>
                    <input
                      type="text"
                      placeholder="http://localhost:11434/v1"
                      value={provider.baseUrl || ''}
                      onChange={(e) => onUpdateProvider('custom', { baseUrl: e.target.value })}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-zinc-200 font-mono focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                )}
              </div>

              {/* Test Result Message */}
              {testRes && (
                <div
                  className={`text-xs p-2.5 rounded-lg font-mono flex items-start gap-2 ${
                    testRes.ok
                      ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/60'
                      : 'bg-rose-950/40 text-rose-300 border border-rose-800/60'
                  }`}
                >
                  {testRes.ok ? <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /> : <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />}
                  <span className="leading-snug">{testRes.message}</span>
                </div>
              )}

              {/* Models Available Under This Provider */}
              <div className="space-y-1.5 pt-2 border-t border-zinc-800/60">
                <span className="text-[11px] font-mono text-zinc-500 uppercase flex items-center gap-1">
                  <Layers className="w-3 h-3 text-cyan-400" />
                  Available Models ({provider.models.length}):
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {provider.models.map((m) => (
                    <span
                      key={m.id}
                      className="text-[11px] font-mono px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-zinc-300 flex items-center gap-1"
                      title={m.strengths.join(', ')}
                    >
                      <span>{m.id}</span>
                      <span className="text-[9px] text-zinc-500">({m.speed})</span>
                    </span>
                  ))}
                </div>
              </div>

              {/* FAILOVER TESTING SIMULATOR TOGGLE */}
              <div className="pt-2 border-t border-zinc-800/60 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-zinc-300">Simulate Depletion / 429 on this node:</span>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    disabled={!provider.simulateFailover}
                    value={provider.simulateErrorType || '402-quota-exhausted'}
                    onChange={(e) => onUpdateProvider(provider.id, { simulateErrorType: e.target.value as any })}
                    className="bg-zinc-950 border border-zinc-700 rounded px-1.5 py-0.5 text-[11px] text-zinc-300 font-mono disabled:opacity-30"
                  >
                    <option value="402-quota-exhausted">402 Credits Depleted</option>
                    <option value="429-rate-limit">429 Rate Limit</option>
                    <option value="503-server-error">503 Outage</option>
                    <option value="timeout">Timeout</option>
                  </select>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={provider.simulateFailover || false}
                      onChange={(e) => onUpdateProvider(provider.id, { simulateFailover: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-7 h-4 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
