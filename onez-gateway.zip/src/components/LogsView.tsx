import React, { useState } from 'react';
import { 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Clock, 
  Hash, 
  RotateCcw, 
  Search,
  ShieldCheck,
  Eye,
  Layers,
  ArrowRight
} from 'lucide-react';
import { GatewayRequestLog } from '../types/gateway';

interface LogsViewProps {
  logs: GatewayRequestLog[];
  onRefresh: () => void;
}

export const LogsView: React.FC<LogsViewProps> = ({ logs, onRefresh }) => {
  const [selectedLog, setSelectedLog] = useState<GatewayRequestLog | null>(null);
  const [filterText, setFilterText] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredLogs = logs.filter((l) => {
    const matchesText =
      l.id.toLowerCase().includes(filterText.toLowerCase()) ||
      l.requestedModel.toLowerCase().includes(filterText.toLowerCase()) ||
      l.actualProvider.toLowerCase().includes(filterText.toLowerCase()) ||
      l.promptPreview.toLowerCase().includes(filterText.toLowerCase());

    if (statusFilter === 'all') return matchesText;
    if (statusFilter === 'failover') return matchesText && l.status === 'recovered_via_failover';
    if (statusFilter === 'success') return matchesText && l.status === 'success';
    return matchesText;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'recovered_via_failover':
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-cyan-400" />
            Failover Recovered
          </span>
        );
      case 'success':
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            Success (Direct)
          </span>
        );
      default:
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800 flex items-center gap-1">
            <XCircle className="w-3 h-3 text-rose-400" />
            Failed
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span>Gateway Traffic & Failover Audit Logs</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time inspection of API calls, route resolutions, credit depletion fallbacks, and token metrics.
          </p>
        </div>

        <button
          onClick={onRefresh}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium transition-colors self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Refresh Logs</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Filter by ID, requested model, provider, or prompt..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-9 pr-3 py-2 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-cyan-500 font-mono"
          />
        </div>

        <div className="flex items-center gap-1.5 self-end sm:self-auto">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === 'all' ? 'bg-zinc-800 text-cyan-300 border border-zinc-700' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All Logs
          </button>
          <button
            onClick={() => setStatusFilter('failover')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === 'failover' ? 'bg-cyan-950 text-cyan-300 border border-cyan-800' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Failover Events
          </button>
          <button
            onClick={() => setStatusFilter('success')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === 'success' ? 'bg-zinc-800 text-emerald-300 border border-zinc-700' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Direct Success
          </button>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300 font-mono">
            <thead className="bg-zinc-950 border-b border-zinc-800 text-zinc-500 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Requested Model</th>
                <th className="py-3 px-4">Resolved Node</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Failovers</th>
                <th className="py-3 px-4">Latency</th>
                <th className="py-3 px-4">Tokens</th>
                <th className="py-3 px-4 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/80">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-zinc-500 font-sans">
                    No requests logged yet. Run a prompt in the Gateway Studio to view live logs.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-zinc-800/40 transition-colors">
                    <td className="py-3 px-4 text-zinc-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="py-3 px-4 text-cyan-300 font-semibold truncate max-w-[160px]">
                      {log.requestedModel}
                    </td>
                    <td className="py-3 px-4 truncate max-w-[160px]">
                      <span className="text-zinc-200 capitalize font-medium">{log.actualProvider}</span>
                      <span className="text-zinc-500 text-[10px] ml-1">({log.actualModel.split('-')[0]})</span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">{getStatusBadge(log.status)}</td>
                    <td className="py-3 px-4">
                      {log.failovers.length > 0 ? (
                        <span className="text-amber-400 font-semibold">{log.failovers.length} hop(s)</span>
                      ) : (
                        <span className="text-zinc-500">0</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-amber-300">{log.latencyMs}ms</td>
                    <td className="py-3 px-4 text-zinc-400">{log.tokens.total} tok</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedLog(log)}
                        className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-sans text-xs transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Log Inspection Detail Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm text-white font-mono">Request Inspection: {selectedLog.id}</h3>
              </div>
              <button onClick={() => setSelectedLog(null)} className="text-zinc-400 hover:text-white text-sm">
                ✕
              </button>
            </div>

            {/* General Specs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono">
              <div>
                <span className="text-zinc-500 text-[10px] block">Requested Model</span>
                <span className="text-cyan-400 font-semibold">{selectedLog.requestedModel}</span>
              </div>
              <div>
                <span className="text-zinc-500 text-[10px] block">Resolved Provider</span>
                <span className="text-emerald-400 font-semibold capitalize">{selectedLog.actualProvider}</span>
              </div>
              <div>
                <span className="text-zinc-500 text-[10px] block">Total Latency</span>
                <span className="text-amber-400 font-semibold">{selectedLog.latencyMs}ms</span>
              </div>
              <div>
                <span className="text-zinc-500 text-[10px] block">Tokens</span>
                <span className="text-zinc-300 font-semibold">{selectedLog.tokens.total} total</span>
              </div>
            </div>

            {/* Failover Trace Timeline */}
            {selectedLog.failovers.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-mono text-zinc-400 uppercase flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                  Failover Hop Execution Chain
                </span>
                <div className="space-y-1.5 font-mono text-xs">
                  {selectedLog.failovers.map((f, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]"
                    >
                      <div className="flex items-center gap-2 text-amber-300">
                        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                        <span>
                          Step {f.stepIndex + 1} ({f.providerId} / {f.modelId}): {f.errorReason}
                        </span>
                      </div>
                      <span className="text-zinc-500">{f.latencyMs}ms</span>
                    </div>
                  ))}

                  <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 flex items-center justify-between text-emerald-300 text-[11px]">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>
                        Final Successful Hop: {selectedLog.actualProvider} ({selectedLog.actualModel})
                      </span>
                    </div>
                    <span className="font-semibold text-emerald-400">Recovered (200 OK)</span>
                  </div>
                </div>
              </div>
            )}

            {/* Prompt & Response Previews */}
            <div className="space-y-3 pt-2 border-t border-zinc-800">
              <div>
                <span className="text-xs font-semibold text-zinc-400 block mb-1">User Prompt</span>
                <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs text-zinc-300 whitespace-pre-wrap max-h-36 overflow-y-auto">
                  {selectedLog.promptPreview}
                </div>
              </div>

              {selectedLog.responsePreview && (
                <div>
                  <span className="text-xs font-semibold text-zinc-400 block mb-1">Response Preview</span>
                  <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-xs text-zinc-300 whitespace-pre-wrap max-h-48 overflow-y-auto">
                    {selectedLog.responsePreview}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedLog(null)}
                className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-300 font-medium transition-colors"
              >
                Close Inspection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
