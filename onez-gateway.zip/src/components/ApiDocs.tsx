import React, { useState } from 'react';
import { 
  Zap, 
  Copy, 
  Check, 
  Terminal, 
  Code, 
  FileCode, 
  Layers, 
  Key, 
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { ModelCombo } from '../types/gateway';

interface ApiDocsProps {
  combos: ModelCombo[];
}

export const ApiDocs: React.FC<ApiDocsProps> = ({ combos }) => {
  const [activeTab, setActiveTab] = useState<'curl' | 'python' | 'node' | 'cursor'>('curl');
  const [copiedKey, setCopiedKey] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [gatewayKey, setGatewayKey] = useState<string>(
    'oz_live_' + Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 10)
  );

  const origin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';
  const baseUrl = `${origin}/api/v1`;

  const copyKey = () => {
    navigator.clipboard.writeText(gatewayKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const regenerateKey = () => {
    setGatewayKey('oz_live_' + Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 10));
  };

  const codeSnippets = {
    curl: `curl -X POST "${baseUrl}/chat/completions" \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer ${gatewayKey}" \\
  -d '{
    "model": "onez-auto",
    "messages": [
      {
        "role": "user",
        "content": "Write a high-performance database connection pool in Go."
      }
    ],
    "temperature": 0.7,
    "stream": false
  }'`,

    python: `from openai import OpenAI

# OneZ GateWay OpenAI-compatible client
client = OpenAI(
    base_url="${baseUrl}",
    api_key="${gatewayKey}"
)

# Call any virtual model combo or auto-router
# If primary provider credit exhausts, OneZ automatically hops to backup!
response = client.chat.completions.create(
    model="onez-ultra-fast",  # or "onez-auto", "onez-coding-beast"
    messages=[
        {"role": "system", "content": "You are a helpful software engineer."},
        {"role": "user", "content": "Summarize how zero-downtime failover works."}
    ],
    temperature=0.7
)

print("Response:", response.choices[0].message.content)
print("Resolved Provider:", getattr(response, "resolved_provider", "auto"))`,

    node: `import OpenAI from 'openai';

// Point standard OpenAI SDK to OneZ GateWay
const openai = new OpenAI({
  baseURL: '${baseUrl}',
  apiKey: '${gatewayKey}',
});

async function main() {
  const completion = await openai.chat.completions.create({
    model: 'onez-coding-beast',
    messages: [
      { role: 'user', content: 'Create a microservice architecture in TypeScript.' }
    ],
    stream: true,
  });

  for await (const chunk of completion) {
    process.stdout.write(chunk.choices[0]?.delta?.content || '');
  }
}

main();`,

    cursor: `{
  "models": [
    {
      "title": "OneZ GateWay (Auto Failover)",
      "provider": "openai",
      "model": "onez-auto",
      "apiKey": "${gatewayKey}",
      "apiBase": "${baseUrl}"
    },
    {
      "title": "OneZ Ultra-Fast (Sub-300ms)",
      "provider": "openai",
      "model": "onez-ultra-fast",
      "apiKey": "${gatewayKey}",
      "apiBase": "${baseUrl}"
    },
    {
      "title": "OneZ Coding Beast",
      "provider": "openai",
      "model": "onez-coding-beast",
      "apiKey": "${gatewayKey}",
      "apiBase": "${baseUrl}"
    }
  ]
}`,
  };

  const copyCode = () => {
    navigator.clipboard.writeText(codeSnippets[activeTab]);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-cyan-400" />
            <span>OpenAI-Compatible Universal API & SDK Setup</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            OneZ GateWay is 100% drop-in compatible with the OpenAI API specification. Use your existing OpenAI libraries, LangChain, Cursor IDE, or direct HTTP requests.
          </p>
        </div>
      </div>

      {/* Gateway Key & Endpoints Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Gateway Master Key Card */}
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-zinc-400">
            <span className="flex items-center gap-1.5 text-zinc-200 font-semibold">
              <Key className="w-3.5 h-3.5 text-cyan-400" />
              Gateway Authorization Key
            </span>
            <button
              onClick={regenerateKey}
              className="text-[11px] text-zinc-500 hover:text-zinc-300 flex items-center gap-1 transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Rotate</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={gatewayKey}
              className="flex-1 bg-zinc-950 border border-zinc-700/80 rounded-lg px-3 py-1.5 text-xs text-cyan-300 font-mono focus:outline-none"
            />
            <button
              onClick={copyKey}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium flex items-center gap-1 transition-colors"
            >
              {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedKey ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* API Base URL Card */}
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-4 space-y-2">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-zinc-200">
            <Terminal className="w-3.5 h-3.5 text-indigo-400" />
            OpenAI Base URL (Plug into any library)
          </span>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={baseUrl}
              className="flex-1 bg-zinc-950 border border-zinc-700/80 rounded-lg px-3 py-1.5 text-xs text-indigo-300 font-mono focus:outline-none"
            />
            <button
              onClick={() => {
                navigator.clipboard.writeText(baseUrl);
              }}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium flex items-center gap-1 transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </button>
          </div>
        </div>
      </div>

      {/* Code Snippets Viewer */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl shadow-sm overflow-hidden">
        {/* Tab Selector */}
        <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-950 px-4 py-2.5">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('curl')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeTab === 'curl' ? 'bg-zinc-800 text-cyan-300' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              cURL (Bash)
            </button>
            <button
              onClick={() => setActiveTab('python')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeTab === 'python' ? 'bg-zinc-800 text-cyan-300' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Python (openai SDK)
            </button>
            <button
              onClick={() => setActiveTab('node')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeTab === 'node' ? 'bg-zinc-800 text-cyan-300' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              TypeScript / Node.js
            </button>
            <button
              onClick={() => setActiveTab('cursor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeTab === 'cursor' ? 'bg-zinc-800 text-cyan-300' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Cursor & VS Code
            </button>
          </div>

          <button
            onClick={copyCode}
            className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-200 transition-colors"
          >
            {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedCode ? 'Copied Snippet!' : 'Copy Code'}</span>
          </button>
        </div>

        {/* Code Block */}
        <div className="p-4 bg-zinc-950 font-mono text-xs text-zinc-300 overflow-x-auto">
          <pre>{codeSnippets[activeTab]}</pre>
        </div>
      </div>

      {/* Available Models Reference Table */}
      <div className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 space-y-3">
        <h3 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Active OneZ Gateway Models (Callable via API)</span>
        </h3>
        <p className="text-xs text-zinc-400">
          Pass any of these model slugs in the <code className="text-zinc-300 font-mono">model</code> parameter of your API request:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
          {combos.map((c) => (
            <div
              key={c.slug}
              className="p-3 rounded-lg bg-zinc-950 border border-zinc-800/80 font-mono text-xs space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="text-cyan-400 font-bold">{c.slug}</span>
                <span className="text-[10px] text-zinc-500 uppercase">{c.cascade.length} Tiers</span>
              </div>
              <p className="text-[11px] text-zinc-400 line-clamp-1 font-sans">{c.name}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
