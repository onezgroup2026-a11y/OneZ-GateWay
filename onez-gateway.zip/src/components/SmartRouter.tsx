import React, { useState } from 'react';
import { 
  ArrowRightLeft, 
  Code2, 
  BrainCircuit, 
  Zap, 
  PenTool, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight,
  Layers,
  Search
} from 'lucide-react';
import { SmartIntentRoute, ModelCombo } from '../types/gateway';

interface SmartRouterProps {
  routes: SmartIntentRoute[];
  combos: ModelCombo[];
  onUpdateRoutes: (routes: SmartIntentRoute[]) => Promise<void>;
  onTestCombo: (slug: string) => void;
}

export const SmartRouter: React.FC<SmartRouterProps> = ({
  routes,
  combos,
  onUpdateRoutes,
  onTestCombo,
}) => {
  const [testPrompt, setTestPrompt] = useState<string>(
    'Write a TypeScript function that implements LRU cache with O(1) get and put.'
  );

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'code':
        return Code2;
      case 'reasoning':
        return BrainCircuit;
      case 'fast_chat':
        return Zap;
      case 'creative':
        return PenTool;
      default:
        return ShieldCheck;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'code':
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      case 'reasoning':
        return 'text-purple-400 bg-purple-950/40 border-purple-800/60';
      case 'fast_chat':
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 'creative':
        return 'text-pink-400 bg-pink-950/40 border-pink-800/60';
      default:
        return 'text-cyan-400 bg-cyan-950/40 border-cyan-800/60';
    }
  };

  // Live evaluation of testPrompt
  const evaluateIntent = () => {
    const lower = testPrompt.toLowerCase();
    for (const r of routes) {
      if (r.category === 'general') continue;
      const matched = r.keywords.filter((k) => lower.includes(k.toLowerCase()));
      if (matched.length > 0) {
        const combo = combos.find((c) => c.id === r.preferredComboId);
        return {
          route: r,
          matched,
          combo,
        };
      }
    }
    const general = routes.find((r) => r.category === 'general');
    const combo = combos.find((c) => c.id === general?.preferredComboId);
    return {
      route: general,
      matched: [],
      combo,
    };
  };

  const matchResult = evaluateIntent();

  const handlePreferredComboChange = async (category: string, comboId: string) => {
    const updated = routes.map((r) => (r.category === category ? { ...r, preferredComboId: comboId } : r));
    await onUpdateRoutes(updated);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-cyan-400" />
            <span>Task-Adaptive Smart Auto-Router</span>
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Incoming requests directed to <code className="text-cyan-300 font-mono">onez-auto</code> are automatically classified by intent (coding, math, fast chat, creative writing) and dynamically dispatched to the fastest, highest-accuracy model cascade.
          </p>
        </div>
      </div>

      {/* Live Intent Simulator / Tester */}
      <div className="bg-gradient-to-br from-zinc-900 via-zinc-900/90 to-zinc-950 border border-zinc-800 rounded-xl p-5 space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-zinc-200">Live Intent Classifier & Routing Simulator</h3>
          </div>
          <span className="text-[11px] font-mono text-zinc-500">Real-Time Zero Latency Evaluation</span>
        </div>

        <div>
          <input
            type="text"
            value={testPrompt}
            onChange={(e) => setTestPrompt(e.target.value)}
            placeholder="Type any prompt to test which model OneZ GateWay selects..."
            className="w-full bg-zinc-950 border border-zinc-700/80 rounded-lg px-3.5 py-2.5 text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-cyan-500 font-sans"
          />
        </div>

        {/* Evaluation Output Card */}
        {matchResult.route && (
          <div className="bg-zinc-950/80 border border-zinc-800 rounded-xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <span className={`px-2.5 py-1 rounded-md text-xs font-semibold border ${getCategoryColor(matchResult.route.category)}`}>
                  Detected Intent: {matchResult.route.label}
                </span>
                {matchResult.matched.length > 0 && (
                  <span className="text-xs text-zinc-400 font-mono">
                    Keywords: <strong className="text-cyan-300">{matchResult.matched.join(', ')}</strong>
                  </span>
                )}
              </div>

              {matchResult.combo && (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-400">Routes to:</span>
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-zinc-800 text-cyan-300 border border-zinc-700">
                    {matchResult.combo.name} ({matchResult.combo.slug})
                  </span>
                  <button
                    onClick={() => matchResult.combo && onTestCombo(matchResult.combo.slug)}
                    className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 hover:bg-cyan-900 transition-colors"
                  >
                    Test
                  </button>
                </div>
              )}
            </div>

            {/* Cascade Waterfall Preview for this matched intent */}
            {(() => {
              const activeCombo = matchResult.combo;
              if (!activeCombo) return null;
              return (
                <div className="flex items-center flex-wrap gap-2 pt-2 border-t border-zinc-800/80 text-xs font-mono">
                  <span className="text-zinc-500 text-[11px] uppercase">Execution Cascade:</span>
                  {activeCombo.cascade.map((step, idx) => (
                    <React.Fragment key={idx}>
                      <span className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300">
                        {idx + 1}. {step.providerId} / {step.modelId.split('-')[0]}
                      </span>
                      {idx < activeCombo.cascade.length - 1 && (
                        <ArrowRight className="w-3 h-3 text-zinc-600" />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              );
            })()}
          </div>
        )}
      </div>

      {/* Routing Rules & Intent Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {routes.map((route) => {
          const Icon = getCategoryIcon(route.category);
          const colorClass = getCategoryColor(route.category);
          const currentCombo = combos.find((c) => c.id === route.preferredComboId);

          return (
            <div
              key={route.category}
              className="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 space-y-3.5 hover:border-zinc-700 transition-all shadow-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center border ${colorClass}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-zinc-100">{route.label}</h3>
                    <p className="text-xs text-zinc-400">{route.description}</p>
                  </div>
                </div>
              </div>

              {/* Preferred Model Combo Selector */}
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">
                  Dispatched Virtual Combo:
                </label>
                <select
                  value={route.preferredComboId}
                  onChange={(e) => handlePreferredComboChange(route.category, e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-xs text-zinc-200 font-mono focus:outline-none focus:border-cyan-500"
                >
                  {combos.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.slug})
                    </option>
                  ))}
                </select>
              </div>

              {/* Keyword Triggers */}
              {route.keywords.length > 0 && (
                <div>
                  <span className="text-[11px] font-mono text-zinc-500 uppercase block mb-1.5">
                    Trigger Keywords ({route.keywords.length}):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {route.keywords.map((kw, i) => (
                      <span
                        key={i}
                        className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800/80 text-zinc-400 border border-zinc-700/50"
                      >
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
