import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Playground } from './components/Playground';
import { CombosManager } from './components/CombosManager';
import { SmartRouter } from './components/SmartRouter';
import { ProviderVault } from './components/ProviderVault';
import { ApiDocs } from './components/ApiDocs';
import { LogsView } from './components/LogsView';
import { 
  GatewayStats, 
  ModelCombo, 
  ProviderConfig, 
  SmartIntentRoute, 
  GatewayRequestLog,
  ProviderType 
} from './types/gateway';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('playground');
  const [stats, setStats] = useState<GatewayStats>({
    totalRequests: 0,
    successRate: 100,
    failoversRecovered: 0,
    avgLatencyMs: 280,
    totalTokens: 0,
    uptimeHours: 99.99,
    activeProviders: 2,
    activeCombos: 5,
  });

  const [combos, setCombos] = useState<ModelCombo[]>([]);
  const [providers, setProviders] = useState<ProviderConfig[]>([]);
  const [smartRoutes, setSmartRoutes] = useState<SmartIntentRoute[]>([]);
  const [logs, setLogs] = useState<GatewayRequestLog[]>([]);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showNotification = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3500);
  };

  // Fetch initial data
  const fetchData = useCallback(async () => {
    try {
      const [statsRes, combosRes, providersRes, routesRes, logsRes] = await Promise.all([
        fetch('/api/gateway/stats'),
        fetch('/api/gateway/combos'),
        fetch('/api/gateway/providers'),
        fetch('/api/gateway/smart-routes'),
        fetch('/api/gateway/logs'),
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (combosRes.ok) setCombos(await combosRes.json());
      if (providersRes.ok) setProviders(await providersRes.json());
      if (routesRes.ok) setSmartRoutes(await routesRes.json());
      if (logsRes.ok) setLogs(await logsRes.json());
    } catch (err) {
      console.error('Failed to fetch gateway data:', err);
    }
  }, []);

  useEffect(() => {
    fetchData();
    // Poll stats & logs periodically
    const timer = setInterval(() => {
      fetch('/api/gateway/stats')
        .then((r) => r.json())
        .then((s) => setStats(s))
        .catch(() => {});
      fetch('/api/gateway/logs')
        .then((r) => r.json())
        .then((l) => setLogs(l))
        .catch(() => {});
    }, 4000);
    return () => clearInterval(timer);
  }, [fetchData]);

  // Provider update handler
  const handleUpdateProvider = async (id: ProviderType, updates: Partial<ProviderConfig>) => {
    try {
      const res = await fetch(`/api/gateway/providers/${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        showNotification(`Updated ${id} provider configuration`);
        fetchData();
      } else {
        showNotification(`Failed to update ${id}`, 'error');
      }
    } catch {
      showNotification('Connection error while updating provider', 'error');
    }
  };

  // Provider test handler
  const handleTestProvider = async (id: ProviderType) => {
    try {
      const res = await fetch(`/api/gateway/providers/${id}/test`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data.ok) {
        showNotification(`Connection to ${id} successful (${data.latencyMs}ms)`, 'success');
      } else {
        showNotification(`Connection test failed: ${data.message}`, 'error');
      }
      fetchData();
      return data;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Test failed';
      showNotification(msg, 'error');
      return { ok: false, latencyMs: 0, message: msg };
    }
  };

  // Combo save handler
  const handleSaveCombo = async (combo: ModelCombo) => {
    try {
      const res = await fetch('/api/gateway/combos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(combo),
      });
      if (res.ok) {
        showNotification(`Successfully saved Model Combo: ${combo.slug}`);
        fetchData();
      } else {
        showNotification('Failed to save combo', 'error');
      }
    } catch {
      showNotification('Network error while saving combo', 'error');
    }
  };

  // Combo delete handler
  const handleDeleteCombo = async (slug: string) => {
    try {
      const res = await fetch(`/api/gateway/combos/${slug}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        showNotification(`Deleted combo ${slug}`);
        fetchData();
      }
    } catch {
      showNotification('Failed to delete combo', 'error');
    }
  };

  // Smart routes update
  const handleUpdateRoutes = async (routes: SmartIntentRoute[]) => {
    try {
      const res = await fetch('/api/gateway/smart-routes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(routes),
      });
      if (res.ok) {
        setSmartRoutes(routes);
        showNotification('Updated Smart Router Intent rules');
      }
    } catch {
      showNotification('Failed to update routes', 'error');
    }
  };

  // Quick switch to studio with selected combo
  const handleTestCombo = (slug: string) => {
    setActiveTab('playground');
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Global Toast Notification */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 animate-bounce">
          <div
            className={`px-4 py-2.5 rounded-xl border text-xs font-medium shadow-2xl flex items-center gap-2 ${
              notification.type === 'error'
                ? 'bg-rose-950 text-rose-200 border-rose-800'
                : 'bg-zinc-900 text-cyan-300 border-cyan-700/70'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            <span>{notification.message}</span>
          </div>
        </div>
      )}

      {/* Main Header with Navigation & Live Telemetry */}
      <Header
        stats={stats}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        appUrl={typeof window !== 'undefined' ? window.location.origin : ''}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'playground' && (
          <Playground
            combos={combos}
            providers={providers}
            onStatsRefresh={fetchData}
          />
        )}

        {activeTab === 'combos' && (
          <CombosManager
            combos={combos}
            providers={providers}
            onSaveCombo={handleSaveCombo}
            onDeleteCombo={handleDeleteCombo}
            onTestCombo={handleTestCombo}
          />
        )}

        {activeTab === 'router' && (
          <SmartRouter
            routes={smartRoutes}
            combos={combos}
            onUpdateRoutes={handleUpdateRoutes}
            onTestCombo={handleTestCombo}
          />
        )}

        {activeTab === 'providers' && (
          <ProviderVault
            providers={providers}
            onUpdateProvider={handleUpdateProvider}
            onTestProvider={handleTestProvider}
          />
        )}

        {activeTab === 'integration' && (
          <ApiDocs combos={combos} />
        )}

        {activeTab === 'logs' && (
          <LogsView logs={logs} onRefresh={fetchData} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950/80 py-4 text-center text-xs text-zinc-600">
        <p className="font-mono">
          OneZ GateWay • Zero-Downtime Universal AI Model Aggregator & Intelligent Failover Switch
        </p>
      </footer>
    </div>
  );
}
