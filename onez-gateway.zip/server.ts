import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { gatewayEngine } from './server/gatewayEngine.js';
import { ProviderType } from './src/types/gateway.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Enable CORS and JSON parsing
app.use((req: Request, res: Response, next: NextFunction) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-onez-api-key, X-Requested-With');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ==========================================
// 1. OPENAI-COMPATIBLE API ENDPOINTS (/api/v1/*)
// ==========================================

/**
 * GET /api/v1/models
 * Lists all available models including virtual combos and direct provider models
 */
app.get('/api/v1/models', (req: Request, res: Response) => {
  const combos = gatewayEngine.getCombos();
  const providers = gatewayEngine.getProviders();

  const modelList: Array<{
    id: string;
    object: string;
    created: number;
    owned_by: string;
    permission: unknown[];
    root: string;
    parent: null;
    meta?: {
      type: 'combo' | 'provider_model';
      description?: string;
      cascade?: unknown[];
    };
  }> = [];

  // Add combos first
  for (const c of combos) {
    modelList.push({
      id: c.slug,
      object: 'model',
      created: 1728000000,
      owned_by: 'onez-gateway',
      permission: [],
      root: c.slug,
      parent: null,
      meta: {
        type: 'combo',
        description: c.description,
        cascade: c.cascade,
      },
    });
  }

  // Add individual provider models
  for (const p of providers) {
    for (const m of p.models) {
      modelList.push({
        id: m.id,
        object: 'model',
        created: 1728000000,
        owned_by: p.id,
        permission: [],
        root: m.id,
        parent: null,
        meta: {
          type: 'provider_model',
          description: m.name,
        },
      });
    }
  }

  res.json({
    object: 'list',
    data: modelList,
  });
});

/**
 * POST /api/v1/chat/completions
 * Standard OpenAI Chat Completions Endpoint
 * Seamlessly routes across model combos, intent classifiers, and auto-fails over on token/credit depletion
 */
app.post('/api/v1/chat/completions', async (req: Request, res: Response) => {
  const {
    model = 'onez-auto',
    messages = [],
    temperature = 0.7,
    max_tokens = 2048,
    stream = false,
    simulate_failover = false,
  } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({
      error: {
        message: 'Invalid request: "messages" must be a non-empty array of objects.',
        type: 'invalid_request_error',
        param: 'messages',
        code: null,
      },
    });
  }

  try {
    const result = await gatewayEngine.executeChatCompletion({
      model,
      messages,
      temperature,
      max_tokens,
      stream: !!stream,
      simulateFailureOnPrimary: !!simulate_failover,
    });

    // Provide OneZ Gateway custom diagnostics headers
    res.setHeader('x-onez-resolved-provider', result.resolvedProvider);
    res.setHeader('x-onez-resolved-model', result.resolvedModel);
    res.setHeader('x-onez-failovers', result.failovers.length.toString());
    res.setHeader('x-onez-latency-ms', result.latencyMs.toString());

    if (stream) {
      // Stream in Server-Sent Events (SSE) format
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      const chunkId = `chatcmpl-${result.id}`;
      const created = Math.floor(Date.now() / 1000);

      // Send initial role chunk
      const firstChunk = {
        id: chunkId,
        object: 'chat.completion.chunk',
        created,
        model,
        resolved_provider: result.resolvedProvider,
        resolved_model: result.resolvedModel,
        failover_count: result.failovers.length,
        choices: [
          {
            index: 0,
            delta: { role: 'assistant', content: '' },
            finish_reason: null,
          },
        ],
      };
      res.write(`data: ${JSON.stringify(firstChunk)}\n\n`);

      // Stream content in chunks for realistic responsiveness
      const words = result.content.split(' ');
      for (let i = 0; i < words.length; i++) {
        const text = (i === 0 ? '' : ' ') + words[i];
        const contentChunk = {
          id: chunkId,
          object: 'chat.completion.chunk',
          created,
          model,
          choices: [
            {
              index: 0,
              delta: { content: text },
              finish_reason: null,
            },
          ],
        };
        res.write(`data: ${JSON.stringify(contentChunk)}\n\n`);
        // Small delay to simulate progressive streaming
        if (words.length > 20) {
          await new Promise((resolve) => setTimeout(resolve, 8));
        }
      }

      // Final stop chunk
      const finalChunk = {
        id: chunkId,
        object: 'chat.completion.chunk',
        created,
        model,
        choices: [
          {
            index: 0,
            delta: {},
            finish_reason: 'stop',
          },
        ],
        usage: result.usage,
      };
      res.write(`data: ${JSON.stringify(finalChunk)}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    } else {
      // Non-streaming standard OpenAI JSON response
      res.json({
        id: `chatcmpl-${result.id}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model,
        resolved_provider: result.resolvedProvider,
        resolved_model: result.resolvedModel,
        failovers_triggered: result.failovers.length,
        failover_trace: result.failovers,
        choices: [
          {
            index: 0,
            message: {
              role: 'assistant',
              content: result.content,
            },
            finish_reason: 'stop',
          },
        ],
        usage: result.usage,
      });
    }
  } catch (err: unknown) {
    const errMsg = err instanceof Error ? err.message : String(err);
    res.status(500).json({
      error: {
        message: `OneZ GateWay Error: ${errMsg}`,
        type: 'gateway_error',
        param: null,
        code: 'gateway_execution_failed',
      },
    });
  }
});

/**
 * POST /api/v1/route-query
 * Preview the routing and cascade plan for a given prompt
 */
app.post('/api/v1/route-query', (req: Request, res: Response) => {
  const { model = 'onez-auto', prompt = '' } = req.body;
  const classification = gatewayEngine.classifyIntent(prompt);
  const cascade = gatewayEngine.resolveCascade(model, prompt);

  res.json({
    requestedModel: model,
    classification,
    resolvedCascade: cascade,
  });
});

// ==========================================
// 2. GATEWAY MANAGEMENT ENDPOINTS
// ==========================================

app.get('/api/gateway/stats', (req: Request, res: Response) => {
  res.json(gatewayEngine.getStats());
});

app.get('/api/gateway/logs', (req: Request, res: Response) => {
  res.json(gatewayEngine.getLogs());
});

app.get('/api/gateway/providers', (req: Request, res: Response) => {
  res.json(gatewayEngine.getProviders());
});

app.post('/api/gateway/providers/:id', (req: Request, res: Response) => {
  const id = req.params.id as ProviderType;
  const updated = gatewayEngine.updateProvider(id, req.body);
  if (!updated) {
    return res.status(404).json({ error: 'Provider not found' });
  }
  res.json(updated);
});

app.post('/api/gateway/providers/:id/test', async (req: Request, res: Response) => {
  const id = req.params.id as ProviderType;
  const testResult = await gatewayEngine.testProviderConnection(id);
  res.json(testResult);
});

app.get('/api/gateway/combos', (req: Request, res: Response) => {
  res.json(gatewayEngine.getCombos());
});

app.post('/api/gateway/combos', (req: Request, res: Response) => {
  const combo = req.body;
  if (!combo.name || !combo.slug || !Array.isArray(combo.cascade) || combo.cascade.length === 0) {
    return res.status(400).json({ error: 'Missing name, slug, or cascade steps' });
  }
  const saved = gatewayEngine.saveCombo(combo);
  res.json(saved);
});

app.delete('/api/gateway/combos/:slug', (req: Request, res: Response) => {
  const slug = req.params.slug;
  const success = gatewayEngine.deleteCombo(slug);
  res.json({ success });
});

app.get('/api/gateway/smart-routes', (req: Request, res: Response) => {
  res.json(gatewayEngine.getSmartRoutes());
});

app.post('/api/gateway/smart-routes', (req: Request, res: Response) => {
  gatewayEngine.updateSmartRoutes(req.body);
  res.json({ success: true });
});

// ==========================================
// 3. FRONTEND SERVING / VITE MIDDLEWARE
// ==========================================

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Development mode: Mount Vite middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production mode: Serve dist folder
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`⚡ OneZ GateWay running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
